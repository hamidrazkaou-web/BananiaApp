package com.mentalreverb.banania;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
}
